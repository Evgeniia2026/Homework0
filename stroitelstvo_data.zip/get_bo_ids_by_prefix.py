"""Map cohort INNs to public BO IDs with a small number of filtered searches.

The public extended-search endpoint accepts `okved=41.20` and a substring in
`inn`. Split the cohort by its first three INN digits and paginate each query.
Large responses are split again to avoid the service's deep-page limit.
"""

from __future__ import annotations

import csv
import gzip
import html
import json
import re
import time
from collections import defaultdict
from pathlib import Path

import requests


ROOT = "https://bo.nalog.gov.ru"
WORK = Path("work/bo_local")
PAGES = WORK / "search_pages_prefix"
PAGES.mkdir(parents=True, exist_ok=True)
SIZE = 2000


def clean(value):
    return html.unescape(re.sub(r"<[^>]+>", "", str(value or ""))).strip()


def get_page(session, prefix, page):
    path = PAGES / f"inn_{prefix}_page_{page:03d}.json.gz"
    if path.exists():
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)
    for attempt in range(4):
        try:
            response = session.get(ROOT + "/advanced-search/organizations",
                                   params={"okved": "41.20", "inn": prefix,
                                           "page": page, "size": SIZE},
                                   timeout=(15, 45))
        except requests.RequestException:
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)
            continue
        if response.status_code in (403, 429):
            raise RuntimeError(f"Service paused: HTTP {response.status_code}")
        if response.status_code in (500, 502, 503, 504):
            if attempt == 3:
                response.raise_for_status()
            time.sleep(2 ** attempt)
            continue
        response.raise_for_status()
        data = response.json()
        if int(data["number"]) != page or not isinstance(data["content"], list):
            raise ValueError(f"Unexpected response for {prefix}, page {page}")
        with gzip.open(path, "wt", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        time.sleep(0.3)
        return data
    raise RuntimeError(f"Failed {prefix}, page {page}")


def main():
    with (WORK / "cohort_4120.csv").open(encoding="utf-8-sig", newline="") as f:
        cohort = {row["inn"]: row for row in csv.DictReader(f)}
    done = set()
    with (WORK / "status.jsonl").open(encoding="utf-8") as f:
        for line in f:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if record.get("status") in ("ok", "not_found", "no_reports"):
                done.add(record["inn"])
    targets = set(cohort) - done
    groups = defaultdict(set)
    for inn in targets:
        groups[inn[:3]].add(inn)
    print(f"Unprocessed INNs: {len(targets)}; three-digit groups: {len(groups)}", flush=True)
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 (compatible; ConstructionResearch/1.0)",
                      "Accept": "application/json, text/plain, */*",
                      "Referer": ROOT + "/"})
    found = {}
    if (WORK / "id_map_4120.csv").exists():
        with (WORK / "id_map_4120.csv").open(encoding="utf-8-sig", newline="") as f:
            found.update({row["inn"]: row for row in csv.DictReader(f)})
    pending = [(prefix, inns) for prefix, inns in sorted(groups.items())]
    checked = 0
    while pending:
        prefix, wanted = pending.pop(0)
        if wanted <= set(found):
            continue
        first = get_page(s, prefix, 0)
        count = int(first["totalElements"])
        # Elasticsearch-style deep pagination on this endpoint fails past ~10k.
        if count > 9000 and len(prefix) < 7:
            subgroups = defaultdict(set)
            for inn in wanted:
                subgroups[inn[:len(prefix) + 1]].add(inn)
            pending = sorted(subgroups.items()) + pending
            print(f"split {prefix}: {count} results into {len(subgroups)} groups", flush=True)
            continue
        pages = int(first["totalPages"])
        for page in range(pages):
            data = first if page == 0 else get_page(s, prefix, page)
            for row in data["content"]:
                inn = clean(row.get("inn"))
                if inn in wanted and clean(row.get("okved2")) == "41.20":
                    found[inn] = {"inn": inn, "org_id": row["id"],
                                  "ogrn": str(row.get("ogrn") or "")}
        checked += 1
        if checked % 25 == 0 or not pending:
            print(f"groups {checked}; matched {len(set(found) & targets)}/{len(targets)}", flush=True)
        with (WORK / "id_map_4120.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["inn", "org_id", "ogrn"])
            writer.writeheader()
            writer.writerows(found.values())
    print(f"Final matched {len(set(found) & targets)}/{len(targets)}; "
          f"remaining use exact INN search", flush=True)


if __name__ == "__main__":
    main()
