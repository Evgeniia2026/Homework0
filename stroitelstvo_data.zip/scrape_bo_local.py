"""Collect public BO annual financial lines for the exact 41.20 SME cohort.

The script is restartable: each completed INN is committed to status.jsonl only
after its financial rows have been written. Run locally with network access.
"""

from __future__ import annotations

import argparse
import csv
import html
import json
import random
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import openpyxl
import requests


ROOT = "https://bo.nalog.gov.ru"
SOURCE = Path("/Users/nguyenphuctue/Downloads/Реестр.xlsx")
WORK = Path("work/bo_local")
COHORT = WORK / "cohort_4120.csv"
ROWS = WORK / "reports.jsonl"
STATUS = WORK / "status.jsonl"
ID_MAP_PATH = WORK / "id_map_4120.csv"
YEAR_MIN, YEAR_MAX = 2019, 2025
ID_MAP: dict[str, dict] = {}

_thread = threading.local()
_rate_lock = threading.Lock()
_next_request = 0.0


def prepare_cohort() -> list[dict]:
    WORK.mkdir(parents=True, exist_ok=True)
    if COHORT.exists():
        with COHORT.open(encoding="utf-8-sig", newline="") as f:
            return list(csv.DictReader(f))
    book = openpyxl.load_workbook(SOURCE, read_only=True, data_only=True)
    sheet = book.active
    sheet.reset_dimensions()
    values = sheet.values
    title = next(values)[0]
    next(values)
    header = next(values)
    fields = ["Наименование / ФИО", "Тип субъекта", "Категория", "ОГРН", "ИНН",
              "Основной вид деятельности", "Регион", "Район", "Город",
              "Населенный пункт", "Дата исключения из реестра"]
    assert all(field in header for field in fields), "Unexpected Excel columns"
    ix = {field: header.index(field) for field in fields}
    cohort = {}
    for row in values:
        if len(row) <= ix["Дата исключения из реестра"]:
            continue
        if row[ix["Тип субъекта"]] != "Юридическое лицо":
            continue
        if row[ix["Категория"]] not in ("Малое предприятие", "Среднее предприятие"):
            continue
        if row[ix["Дата исключения из реестра"]] not in (None, ""):
            continue
        activity = str(row[ix["Основной вид деятельности"]] or "").strip()
        match = re.match(r"^(\d{2}\.\d{1,2})(?=\s|$)", activity)
        if not match or match.group(1) != "41.20":
            continue
        inn = str(row[ix["ИНН"]] or "").strip()
        if not re.fullmatch(r"\d{10}", inn):
            continue
        cohort.setdefault(inn, {
            "inn": inn,
            "ogrn": str(row[ix["ОГРН"]] or "").strip(),
            "name": str(row[ix["Наименование / ФИО"]] or "").strip(),
            "category": row[ix["Категория"]],
            "okved": "41.20",
            "region": re.sub(r"^\d{2}\s*-\s*", "", str(row[ix["Регион"]] or "")).strip(),
            "district": str(row[ix["Район"]] or "").strip(),
            "city": str(row[ix["Город"]] or "").strip(),
            "settlement": str(row[ix["Населенный пункт"]] or "").strip(),
        })
    book.close()
    with COHORT.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(next(iter(cohort.values()))))
        writer.writeheader()
        writer.writerows(cohort.values())
    print(f"{title}: {len(cohort)} unique eligible INNs", flush=True)
    return list(cohort.values())


def session() -> requests.Session:
    if not hasattr(_thread, "session"):
        obj = requests.Session()
        obj.headers.update({
            "User-Agent": "Mozilla/5.0 (compatible; ConstructionResearch/1.0)",
            "Accept": "application/json, text/plain, */*",
            "Referer": ROOT + "/",
        })
        _thread.session = obj
    return _thread.session


def rate_limit(interval: float):
    global _next_request
    with _rate_lock:
        now = time.monotonic()
        delay = max(0, _next_request - now)
        _next_request = max(now, _next_request) + interval
    if delay:
        time.sleep(delay)


class AccessPaused(Exception):
    pass


def get_json(path: str, params: dict | None, interval: float):
    url = ROOT + path
    for attempt in range(4):
        rate_limit(interval)
        try:
            response = session().get(url, params=params, timeout=(15, 45))
        except requests.RequestException as exc:
            if attempt == 3:
                raise RuntimeError(f"Network: {type(exc).__name__}: {exc}") from exc
            time.sleep(2 ** attempt + random.random())
            continue
        if response.status_code in (403, 429):
            raise AccessPaused(f"HTTP {response.status_code} at {response.url}")
        if response.status_code == 404:
            return None
        if response.status_code in (500, 502, 503, 504):
            if attempt == 3:
                raise RuntimeError(f"HTTP {response.status_code} at {response.url}")
            time.sleep(2 ** attempt + random.random())
            continue
        response.raise_for_status()
        if "json" not in response.headers.get("Content-Type", "").lower():
            raise RuntimeError(f"Non-JSON response at {response.url}")
        return response.json()
    raise RuntimeError("Retry loop ended unexpectedly")


def number(value):
    if value is None or value == "":
        return None
    try:
        return float(str(value).replace(" ", "").replace("\u00a0", "").replace(",", "."))
    except ValueError:
        return None


def clean(value) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", str(value or ""))).strip()


def fetch_company(company: dict, interval: float) -> tuple[dict, list[dict]]:
    inn = company["inn"]
    mapped = ID_MAP.get(inn)
    if mapped and (not mapped.get("ogrn") or mapped["ogrn"] == company["ogrn"]):
        found = {"id": mapped["org_id"], "inn": inn}
    else:
        search = get_json("/advanced-search/organizations/search",
                          {"query": inn, "page": 0, "size": 20}, interval)
        found = next((entry for entry in (search or {}).get("content", [])
                      if clean(entry.get("inn")) == inn), None)
    if not found:
        return {"inn": inn, "status": "not_found", "rows": 0}, []
    org_id = found["id"]
    reports = get_json(f"/nbo/organizations/{org_id}/bfo/", None, interval)
    if reports is None:
        return {"inn": inn, "status": "no_reports", "rows": 0,
                "org_id": org_id}, []
    if not isinstance(reports, list):
        raise RuntimeError("Unexpected BFO structure: annual period array missing")
    extracted = []
    fetched_at = datetime.now(timezone.utc).isoformat()
    for period in reports:
        try:
            year = int(period.get("period"))
        except (TypeError, ValueError):
            continue
        if not YEAR_MIN <= year <= YEAR_MAX:
            continue
        annual = [item for item in (period.get("typeCorrections") or [])
                  if isinstance(item, dict) and str(item.get("type")) == "12"
                  and isinstance(item.get("correction"), dict)]
        if not annual:
            continue
        # Usually one annual form. If more, prefer the highest correction number.
        selected = max(annual, key=lambda x: number(x["correction"].get("correctionNumber")) or 0)
        correction = selected["correction"]
        form = correction.get("financialResult")
        if not isinstance(form, dict):
            continue
        extracted.append({
            **company,
            "org_id": org_id,
            "year": year,
            "detail_id": correction.get("id"),
            "actual_correction_date": period.get("actualCorrectionDate"),
            "published_correction_date": period.get("publishedCorrectionDate"),
            "revenue_thousand_rub": number(form.get("current2110")),
            "sales_profit_thousand_rub": number(form.get("current2200")),
            "profit_before_tax_thousand_rub": number(form.get("current2300")),
            "interest_expense_thousand_rub": number(form.get("current2330")),
            "income_tax_signed_thousand_rub": number(form.get("current2410")),
            "net_profit_thousand_rub": number(form.get("current2400")),
            "source_url": f"{ROOT}/organizations-card/{org_id}",
            "fetched_at_utc": fetched_at,
        })
    return {"inn": inn, "status": "ok" if extracted else "no_reports",
            "rows": len(extracted), "org_id": org_id}, extracted


def done_inns() -> set[str]:
    if not STATUS.exists():
        return set()
    done = set()
    with STATUS.open(encoding="utf-8") as f:
        for line in f:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if record.get("status") in ("ok", "not_found", "no_reports"):
                done.add(record["inn"])
    return done


def main():
    global ID_MAP
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--mapped-only", action="store_true",
                        help="process only INNs already present in the cached OKVED ID map")
    parser.add_argument("--interval", type=float, default=0.5,
                        help="minimum seconds between requests across all workers")
    args = parser.parse_args()
    cohort = prepare_cohort()
    if ID_MAP_PATH.exists():
        with ID_MAP_PATH.open(encoding="utf-8-sig", newline="") as f:
            ID_MAP = {record["inn"]: record for record in csv.DictReader(f)}
        print(f"Cached OKVED search IDs: {len(ID_MAP)}", flush=True)
    done = done_inns()
    queue = [company for company in cohort if company["inn"] not in done]
    if args.mapped_only:
        queue = [company for company in queue if company["inn"] in ID_MAP]
    if args.limit is not None:
        queue = queue[:args.limit]
    print(f"Done {len(done)} / {len(cohort)}; processing {len(queue)}", flush=True)
    if not queue:
        return
    started = time.monotonic()
    stop = threading.Event()
    with ROWS.open("a", encoding="utf-8") as rowfile, \
         STATUS.open("a", encoding="utf-8") as statusfile, \
         ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(fetch_company, company, args.interval): company
                   for company in queue}
        for count, future in enumerate(as_completed(futures), 1):
            company = futures[future]
            try:
                status, rows = future.result()
            except AccessPaused as exc:
                print(f"ACCESS PAUSED: {exc}; stopping after current jobs", flush=True)
                stop.set()
                for pending in futures:
                    pending.cancel()
                break
            except Exception as exc:
                status = {"inn": company["inn"], "status": "error",
                          "message": str(exc)[:400]}
                rows = []
            for row in rows:
                rowfile.write(json.dumps(row, ensure_ascii=False) + "\n")
            rowfile.flush()
            statusfile.write(json.dumps(status, ensure_ascii=False) + "\n")
            statusfile.flush()
            if count % 25 == 0 or count == len(queue):
                print(f"{count}/{len(queue)} in {time.monotonic()-started:.0f}s; "
                      f"last={status['status']} rows={status.get('rows', 0)}", flush=True)
    if stop.is_set():
        raise SystemExit(2)


if __name__ == "__main__":
    main()
